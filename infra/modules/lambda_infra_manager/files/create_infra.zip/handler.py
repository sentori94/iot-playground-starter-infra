import json
import os
import boto3
import uuid
from datetime import datetime
from decimal import Decimal

# Clients AWS
codebuild = boto3.client('codebuild')
dynamodb = boto3.resource('dynamodb')

PROJECT = os.environ.get('PROJECT', 'iot-playground')
ENVIRONMENT = os.environ.get('ENVIRONMENT', 'dev')
AWS_REGION = os.environ.get('AWS_REGION', 'us-east-1')
DEPLOYMENTS_TABLE = os.environ.get('DEPLOYMENTS_TABLE')
CODEBUILD_PROJECT = os.environ.get('CODEBUILD_PROJECT_APPLY')

# Table DynamoDB
table = dynamodb.Table(DEPLOYMENTS_TABLE)

def lambda_handler(event, context):
    """
    Lambda pour créer l'infrastructure complète via CodeBuild + Terraform
    """
    try:
        # Parser le body de la requête
        if 'body' in event:
            body = json.loads(event['body']) if isinstance(event['body'], str) else event['body']
        else:
            body = event

        # Générer un ID de déploiement unique
        deployment_id = str(uuid.uuid4())
        timestamp = int(datetime.utcnow().timestamp())

        # Paramètres du déploiement
        target_environment = body.get('environment', ENVIRONMENT)
        requested_by = body.get('user', 'anonymous')
        config = body.get('config', {})

        # Créer l'entrée dans DynamoDB
        deployment_item = {
            'deployment_id': deployment_id,
            'environment': target_environment,
            'status': 'INITIATING',
            'terraform_action': 'apply',
            'requested_by': requested_by,
            'created_at': timestamp,
            'updated_at': timestamp,
            'config': json.dumps(config),
            'ttl': timestamp + (30 * 24 * 60 * 60)  # Expire après 30 jours
        }

        table.put_item(Item=deployment_item)
        print(f"✅ Deployment {deployment_id} created in DynamoDB")

        # Démarrer le build CodeBuild
        build_response = codebuild.start_build(
            projectName=CODEBUILD_PROJECT,
            environmentVariablesOverride=[
                {
                    'name': 'DEPLOYMENT_ID',
                    'value': deployment_id,
                    'type': 'PLAINTEXT'
                },
                {
                    'name': 'TARGET_ENVIRONMENT',
                    'value': target_environment,
                    'type': 'PLAINTEXT'
                },
                {
                    'name': 'REQUESTED_BY',
                    'value': requested_by,
                    'type': 'PLAINTEXT'
                }
            ]
        )

        codebuild_id = build_response['build']['id']
        codebuild_arn = build_response['build']['arn']

        # Mettre à jour avec l'ID du build
        table.update_item(
            Key={'deployment_id': deployment_id},
            UpdateExpression='SET codebuild_id = :build_id, codebuild_arn = :build_arn, #status = :status, updated_at = :timestamp',
            ExpressionAttributeNames={'#status': 'status'},
            ExpressionAttributeValues={
                ':build_id': codebuild_id,
                ':build_arn': codebuild_arn,
                ':status': 'STARTED',
                ':timestamp': int(datetime.utcnow().timestamp())
            }
        )

        print(f"🚀 CodeBuild started: {codebuild_id}")

        response_body = {
            'success': True,
            'deployment_id': deployment_id,
            'status': 'STARTED',
            'message': f'Infrastructure deployment has been started via CodeBuild',
            'timestamp': datetime.utcnow().isoformat(),
            'codebuild_id': codebuild_id,
            'check_status_url': f'/infra/status/{deployment_id}',
            'logs_url': f'https://console.aws.amazon.com/codesuite/codebuild/projects/{CODEBUILD_PROJECT}/build/{codebuild_id.split("/")[-1]}/log'
        }

        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps(response_body)
        }

    except Exception as e:
        print(f"❌ Error: {str(e)}")
        import traceback
        traceback.print_exc()

        # Si on a créé un deployment_id, mettre à jour le statut
        if 'deployment_id' in locals():
            try:
                table.update_item(
                    Key={'deployment_id': deployment_id},
                    UpdateExpression='SET #status = :status, error_message = :error, updated_at = :timestamp',
                    ExpressionAttributeNames={'#status': 'status'},
                    ExpressionAttributeValues={
                        ':status': 'FAILED',
                        ':error': str(e),
                        ':timestamp': int(datetime.utcnow().timestamp())
                    }
                )
            except:
                pass

        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                'success': False,
                'error': str(e),
                'message': 'Failed to initiate infrastructure deployment'
            })
        }

