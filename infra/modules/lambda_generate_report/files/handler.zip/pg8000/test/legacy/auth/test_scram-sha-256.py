def test_scram_sha_256(con):
    """Called by GitHub Actions with auth method scram-sha-256.
    We just need to check that we can get a connection.
    """
    pass
