from scramp import *  # noqa: F403,F401


def test_import_all():
    pass
